import socket
import random
import master

#temp = master.temp
HOST = "127.0.0.1"
PORT = 9000
clockVariable = random.randint(1, 10)
def main():
    global clockVariable
    print(f"Logical Clock of Slave is {clockVariable}")
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect((HOST,PORT))
    print(client.getsockname())
    print(f"Slave connected to master at {HOST}:{PORT}")
    msg = str(clockVariable)
    print("sending local logical clock...")
    client.send(msg.encode())
    connected = True
    while connected:
        msg = client.recv(1024).decode()
        print(f"[Master] {msg}")
        average = client.recv(1024).decode()
        print(f"\nUpdated Clock: {average}")
        clockVariable = average


if __name__ == "__main__":
    main()