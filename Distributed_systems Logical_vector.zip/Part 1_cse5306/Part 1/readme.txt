Requirements
Python >= 3.6

Step 1:Open terminal, Run the following command to start the server
$ python3 master.py

Step 2:Open a new terminal, Run the following command to start the client(slave) no 1
$ python3 slave.py

Step 3:Open a new terminal, Run the following command to start the client(slave) no 2
$ python3 slave.py

