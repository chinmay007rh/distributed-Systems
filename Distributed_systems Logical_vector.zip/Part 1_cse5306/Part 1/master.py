import socket
import threading
import random

HOST = "127.0.0.1"
PORT = 9000
clockVariable = random.randint(1, 10)
clientMap = {}
temp = 0
clients = []


def broadcastAvg(conn):
    global clientMap

    timeVariable = float(clockVariable)
    veriableLength = len(clientMap) + 1
    for key, value in clientMap.items():
        timeVariable += float(value)

    average = float(timeVariable / veriableLength)
    average = "{:.2f}".format(average)
    average = str(average)
    for client in clients:
        client.send(average.encode())
    print("Average at Master: ", average)

    return average


def handle_client(conn, addr):
    global temp
    global clockVariable
    temp += 1
    print(f" Slave connected : {temp}")

    connected = True
    while connected:
        msg = conn.recv(1024).decode()

        with threading.Lock():
            clientMap[addr] = float(msg)

        msg = f"clock received was {msg}."
        conn.send(msg.encode())
        if temp >= 2:
            average = broadcastAvg(conn)
            print("Updated Clock: ", average)
            clockVariable = average


def main():
    print(f"Logical Clock of Master is {clockVariable}")
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((HOST, PORT))
    server.listen()

    while True:
        conn, addr = server.accept()
        clients.append(conn)
        thread = threading.Thread(target=handle_client, args=(conn, addr))
        thread.start()


if __name__ == "__main__":
    main()
